// ==========================================================================
// ATLAS - MÓDULO DE SAÚDE, DIETA & BEM-ESTAR (HEALTH AI)
// ==========================================================================
import { AtlasDB } from '../firebase-config.js';

export const HealthModule = {
  painDatabase: {
    lombar: {
      title: 'Dor na Região Lombar (Costas Inferiores)',
      causes: 'Sobrecarga em agachamentos, postura inadequada no dia a dia ou fadiga dos eretores da espinha.',
      ointments: ['Pomada de Salicilato de Metila + Cânfora', 'Gel de Arnica Montana', 'Diclofenaco Dietilamônio Gel (Anti-inflamatório tópico)'],
      otcMedication: ['Paracetamol (Analgésico simples)', 'Dipirona Monoidratada', 'Associação com Relaxante Muscular (sob orientação de farmacêutico)'],
      careTips: 'Aplicação de compressa morna por 15-20 minutos, alongamento suave de glúteos e posteriores de coxa, evitar cargas axiais pesadas por 48 horas.'
    },
    joelho: {
      title: 'Dor ou Desconforto nos Joelhos / Tendão Patelar',
      causes: 'Impacto excessivo em corrida, extensão exagerada no leg press ou encurtamento do quadríceps.',
      ointments: ['Gel Crioterápico com Mentol (Efeito Frio)', 'Diclofenaco Gel Tópico', 'Pomada à base de Arnica'],
      otcMedication: ['Ibuprofeno ou Cetoprofeno em dose padrão para alívio pontual (conforme bula)'],
      careTips: 'Gelo imediato por 15 minutos (crioterapia), redução do volume de saltos/corrida, fortalecimento de glúteo médio e vasto medial.'
    },
    ombro: {
      title: 'Dor nos Ombros (Manguito Rotador / Deltoide)',
      causes: 'Pegada muito aberta no supino, falta de aquecimento rotacional ou sobrecarga no desenvolvimento.',
      ointments: ['Gel anti-inflamatório tópico (Piroxicam ou Diclofenaco)', 'Pomada relaxante muscular com cânfora'],
      otcMedication: ['Dipirona ou Paracetamol para manejo da dor aguda leve'],
      careTips: 'Exercícios com elásticos para rotação externa/interna, evitar supino com amplitude que ultrapasse o plano do tronco temporariamente.'
    },
    panturrilha: {
      title: 'Dor / Espasmo nas Panturrilhas e Canela (Canelite)',
      causes: 'Início repentino de corrida em asfalto, calçado sem amortecimento adequado ou desidratação eletrolítica.',
      ointments: ['Pomada de Arnica com Castanha-da-Índia', 'Gel refrescante com Cânfora'],
      otcMedication: ['Suplementação de Magnésio e Potássio em caso de cãibras recorrentes'],
      careTips: 'Massagem miofascial com rolo de liberação, hidratação abundante com eletrólitos, alternar dias de corrida com bicicleta.'
    }
  },

  init() {
    this.setupListeners();
    this.updateDietRecommendations();
  },

  setupListeners() {
    const painSelect = document.getElementById('pain-region-select');
    if (painSelect) {
      painSelect.addEventListener('change', (e) => this.renderPainInfo(e.target.value));
    }

    const calcDietBtn = document.getElementById('btn-recalc-diet');
    if (calcDietBtn) {
      calcDietBtn.addEventListener('click', () => this.updateDietRecommendations());
    }
  },

  updateDietRecommendations() {
    const user = AtlasDB.getCurrentUser();
    const weight = user ? user.weight : 78.5;
    const goal = document.getElementById('diet-goal-select') ? document.getElementById('diet-goal-select').value : 'Hipertrofia';

    let proteinFactor = 2.0;
    let carbFactor = 4.0;
    let fatFactor = 0.9;
    let goalDescription = '';

    if (goal === 'Emagrecimento') {
      proteinFactor = 2.2;
      carbFactor = 2.4;
      fatFactor = 0.8;
      goalDescription = 'Déficit calórico controlado com alto aporte proteico para preservar a massa magra durante os treinos.';
    } else if (goal === 'Hipertrofia') {
      proteinFactor = 2.0;
      carbFactor = 4.5;
      fatFactor = 1.0;
      goalDescription = 'Superávit calórico limpo para otimizar a síntese proteica e regeneração das fibras musculares pós-treino.';
    } else {
      proteinFactor = 1.9;
      carbFactor = 3.5;
      fatFactor = 0.9;
      goalDescription = 'Equilíbrio isocalórico focado em melhora da densidade muscular e queima gradual de gordura.';
    }

    const proteinGrams = Math.round(weight * proteinFactor);
    const carbGrams = Math.round(weight * carbFactor);
    const fatGrams = Math.round(weight * fatFactor);
    const totalKcal = Math.round((proteinGrams * 4) + (carbGrams * 4) + (fatGrams * 9));

    const resultEl = document.getElementById('diet-recommendation-box');
    if (!resultEl) return;

    resultEl.innerHTML = `
      <div style="background:var(--surface-card); border:1px solid var(--border-accent); border-radius:var(--radius-lg); padding:24px; margin-bottom:20px; box-shadow:var(--shadow-card); backdrop-filter:blur(16px);">
        <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:14px; margin-bottom:20px;">
          <div>
            <div style="display:flex; align-items:center; gap:8px;">
              <span style="font-size:0.75rem; font-weight:800; background:var(--primary-glow); color:var(--primary); padding:3px 10px; border-radius:var(--radius-full); border:1px solid var(--border-accent); letter-spacing:0.04em;">CALIBRADO PELA IA</span>
              <h4 style="font-size:1.25rem; color:var(--text-primary); font-weight:900; font-family:var(--font-heading); margin:0;">Metas Diárias para ${weight} kg</h4>
            </div>
            <p style="font-size:0.86rem; color:var(--text-secondary); margin-top:6px; line-height:1.5;">${goalDescription}</p>
          </div>
          <div style="background:linear-gradient(135deg, rgba(16, 245, 122, 0.12) 0%, rgba(0, 229, 255, 0.12) 100%); border:1.5px solid var(--primary); border-radius:var(--radius-md); padding:10px 20px; color:#fff; font-weight:900; font-size:1.25rem; box-shadow:0 0 20px rgba(16,245,122,0.2);">
            <span class="gradient-text">${totalKcal}</span> <span style="font-size:0.85rem; color:var(--text-secondary); font-weight:700;">kcal / dia</span>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(135px, 1fr)); gap:14px; margin-bottom:20px;">
          <div style="background:var(--surface-sunken); padding:16px 14px; border-radius:var(--radius-md); text-align:center; border:1px solid rgba(16, 245, 122, 0.25); box-shadow:var(--shadow-sm);">
            <div style="font-size:0.72rem; color:var(--text-muted); font-weight:800; letter-spacing:1px;">PROTEÍNAS</div>
            <div style="font-size:1.65rem; color:var(--primary); font-weight:900; margin:4px 0; font-family:var(--font-heading);">${proteinGrams}g</div>
            <div style="font-size:0.75rem; color:var(--text-secondary); font-weight:600;">${(proteinFactor).toFixed(1)}g / kg</div>
          </div>
          <div style="background:var(--surface-sunken); padding:16px 14px; border-radius:var(--radius-md); text-align:center; border:1px solid rgba(0, 229, 255, 0.25); box-shadow:var(--shadow-sm);">
            <div style="font-size:0.72rem; color:var(--text-muted); font-weight:800; letter-spacing:1px;">CARBOIDRATOS</div>
            <div style="font-size:1.65rem; color:var(--secondary); font-weight:900; margin:4px 0; font-family:var(--font-heading);">${carbGrams}g</div>
            <div style="font-size:0.75rem; color:var(--text-secondary); font-weight:600;">${(carbFactor).toFixed(1)}g / kg</div>
          </div>
          <div style="background:var(--surface-sunken); padding:16px 14px; border-radius:var(--radius-md); text-align:center; border:1px solid rgba(255, 179, 0, 0.25); box-shadow:var(--shadow-sm);">
            <div style="font-size:0.72rem; color:var(--text-muted); font-weight:800; letter-spacing:1px;">GORDURAS BOAS</div>
            <div style="font-size:1.65rem; color:var(--energy-amber); font-weight:900; margin:4px 0; font-family:var(--font-heading);">${fatGrams}g</div>
            <div style="font-size:0.75rem; color:var(--text-secondary); font-weight:600;">${(fatFactor).toFixed(1)}g / kg</div>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(240px, 1fr)); gap:16px;">
          <div style="background:var(--surface-sunken); padding:18px; border-radius:var(--radius-md); border-left:3px solid var(--primary); box-shadow:var(--shadow-sm); border-top:1px solid var(--border-subtle); border-right:1px solid var(--border-subtle); border-bottom:1px solid var(--border-subtle);">
            <p style="color:var(--primary); font-size:0.88rem; font-weight:800; margin-bottom:6px;">⚡ Pré-Treino Ideal (1h a 2h antes):</p>
            <p style="font-size:0.84rem; color:var(--text-secondary); line-height:1.6; margin:0;">Carboidrato de absorção gradativa (Banana amassada com aveia e canela, ou tapioca com ovos) + 400ml de água para hidratação das fibras.</p>
          </div>
          <div style="background:var(--surface-sunken); padding:18px; border-radius:var(--radius-md); border-left:3px solid var(--secondary); box-shadow:var(--shadow-sm); border-top:1px solid var(--border-subtle); border-right:1px solid var(--border-subtle); border-bottom:1px solid var(--border-subtle);">
            <p style="color:var(--secondary); font-size:0.88rem; font-weight:800; margin-bottom:6px;">💪 Pós-Treino Regenerador:</p>
            <p style="font-size:0.84rem; color:var(--text-secondary); line-height:1.6; margin:0;">25g a 35g de proteína rápida (Frango grelhado, peixe ou Whey Protein Isolado/Concentrado) associado a arroz, batata ou pão integral para reposição do glicogênio.</p>
          </div>
        </div>
      </div>
    `;
  },

  renderPainInfo(regionKey) {
    const container = document.getElementById('pain-info-display');
    if (!container) return;

    if (!regionKey || !this.painDatabase[regionKey]) {
      container.innerHTML = `<p style="color:var(--text-muted); padding:24px; text-align:center; font-size:0.9rem;">Selecione uma região anatômica acima para visualizar orientações e opções tópicas de alívio.</p>`;
      return;
    }

    const data = this.painDatabase[regionKey];

    container.innerHTML = `
      <div style="background:var(--surface-card); border:1px solid var(--border-glass); border-radius:var(--radius-lg); padding:24px; animation:fadeIn 0.25s ease; box-shadow:var(--shadow-card); backdrop-filter:blur(16px);">
        <h4 style="font-size:1.3rem; color:var(--text-primary); font-weight:900; margin-bottom:6px; font-family:var(--font-heading);">${data.title}</h4>
        <p style="font-size:0.88rem; color:var(--text-secondary); margin-bottom:20px;"><strong>Origem provável no treino:</strong> ${data.causes}</p>

        <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(260px, 1fr)); gap:18px; margin-bottom:20px;">
          <div style="background:var(--surface-sunken); padding:18px; border-radius:var(--radius-md); border:1px solid rgba(16, 245, 122, 0.25); box-shadow:var(--shadow-sm);">
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
              <span style="color:var(--primary); font-size:1.1rem;">🌿</span>
              <p style="font-size:0.9rem; font-weight:800; color:var(--text-primary); margin:0;">Pomadas e Géis Tópicos:</p>
            </div>
            <ul style="font-size:0.84rem; color:var(--text-secondary); margin-left:18px; line-height:1.7; margin-bottom:0;">
              ${data.ointments.map(o => `<li>${o}</li>`).join('')}
            </ul>
          </div>
          <div style="background:var(--surface-sunken); padding:18px; border-radius:var(--radius-md); border:1px solid rgba(0, 229, 255, 0.25); box-shadow:var(--shadow-sm);">
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
              <span style="color:var(--secondary); font-size:1.1rem;">💊</span>
              <p style="font-size:0.9rem; font-weight:800; color:var(--text-primary); margin:0;">Medicamentos Isentos de Prescrição (MIP):</p>
            </div>
            <ul style="font-size:0.84rem; color:var(--text-secondary); margin-left:18px; line-height:1.7; margin-bottom:0;">
              ${data.otcMedication.map(m => `<li>${m}</li>`).join('')}
            </ul>
          </div>
        </div>

        <div style="background:var(--primary-glow); border:1px solid var(--border-accent); border-radius:var(--radius-md); padding:16px 20px;">
          <p style="font-size:0.88rem; font-weight:800; color:var(--primary); margin-bottom:6px;">🛡️ Cuidados Imediatos & Recuperação:</p>
          <p style="font-size:0.84rem; color:var(--text-secondary); line-height:1.6; margin:0;">${data.careTips}</p>
        </div>
      </div>
    `;
  }
};
