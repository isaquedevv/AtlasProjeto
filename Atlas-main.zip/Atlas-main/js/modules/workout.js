// ==========================================================================
// ATLAS - MÓDULO DE ACADEMIA & TREINO (WORKOUT ENGINE)
// Suporte a Live HUD GymTrack e Treinos por Dia da Semana
// ==========================================================================
import { AtlasDB } from '../firebase-config.js';

export const WorkoutModule = {
  activeWorkout: null,
  currentExerciseIndex: 0,
  currentSet: 1,
  currentReps: 0,
  restTimeTotal: 60,
  restTimeRemaining: 0,
  restTimerInterval: null,
  selectedDayKey: 'segunda',

  init() {
    // Detecta o dia atual da semana (0=Dom, 1=Seg, 2=Ter, etc.)
    const dayMap = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
    this.selectedDayKey = dayMap[new Date().getDay()] || 'segunda';

    this.renderExerciseList();
    this.renderWeekSchedule();
    this.setupListeners();
    this.initDefaultActiveWorkout();
  },

  initDefaultActiveWorkout() {
    const schedule = AtlasDB.getWeeklySchedule();
    const todayWorkout = schedule[this.selectedDayKey];

    if (todayWorkout && !todayWorkout.isRest && todayWorkout.exercises && todayWorkout.exercises.length > 0) {
      this.activeWorkout = {
        name: `${todayWorkout.dayName} - ${todayWorkout.title}`,
        exercises: todayWorkout.exercises
      };
      this.loadExerciseToHud(0);
    } else {
      const exercises = AtlasDB.getExercises();
      if (exercises.length > 0) {
        this.activeWorkout = {
          name: 'Treino A - Peito, Ombros e Tríceps',
          exercises: exercises
        };
        this.loadExerciseToHud(0);
      }
    }
  },

  setupListeners() {
    // Botão Concluir Repetição
    const repBtn = document.getElementById('hud-btn-rep');
    if (repBtn) {
      repBtn.addEventListener('click', () => this.incrementRep());
    }

    // Botão Concluir Série
    const setBtn = document.getElementById('hud-btn-set');
    if (setBtn) {
      setBtn.addEventListener('click', () => this.completeSet());
    }

    // Botão Pular Descanso
    const skipRestBtn = document.getElementById('hud-btn-skip-rest');
    if (skipRestBtn) {
      skipRestBtn.addEventListener('click', () => this.stopRestTimer());
    }

    // Botão Próximo Exercício
    const nextExBtn = document.getElementById('hud-btn-next-ex');
    if (nextExBtn) {
      nextExBtn.addEventListener('click', () => this.nextExercise());
    }

    // Formulário Novo Exercício no Catálogo
    const exForm = document.getElementById('form-add-exercise');
    if (exForm) {
      exForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.saveNewExercise();
      });
    }

    // Gerador de Treino IA
    const aiGenBtn = document.getElementById('btn-generate-ai-workout');
    if (aiGenBtn) {
      aiGenBtn.addEventListener('click', () => this.generateAiWorkout());
    }

    // Botão Iniciar Treino do Dia Selecionado
    const startDayBtn = document.getElementById('btn-start-selected-day-workout');
    if (startDayBtn) {
      startDayBtn.addEventListener('click', () => this.startSelectedDayWorkout());
    }

    // Botão Abrir Modal Adicionar Exercício ao Dia
    const openAddDayBtn = document.getElementById('btn-open-add-to-day');
    if (openAddDayBtn) {
      openAddDayBtn.addEventListener('click', () => this.openAddToDayModal());
    }

    // Form Adicionar Exercício ao Dia
    const formAddToDay = document.getElementById('form-add-to-day');
    if (formAddToDay) {
      formAddToDay.addEventListener('submit', (e) => {
        e.preventDefault();
        this.addExerciseToCurrentDay();
      });
    }

    // Botão Abrir Modal Configurar Dia
    const openEditDayBtn = document.getElementById('btn-open-edit-day');
    if (openEditDayBtn) {
      openEditDayBtn.addEventListener('click', () => this.openEditDayModal());
    }

    // Form Configurar Dia
    const formEditDay = document.getElementById('form-edit-day');
    if (formEditDay) {
      formEditDay.addEventListener('submit', (e) => {
        e.preventDefault();
        this.saveEditedDay();
      });
    }
  },

  // ==========================================================================
  // RENDERIZAÇÃO DO CRONOGRAMA SEMANAL (TREINO POR DIA)
  // ==========================================================================
  renderWeekSchedule() {
    const pillsContainer = document.getElementById('week-days-pills');
    if (!pillsContainer) return;

    const schedule = AtlasDB.getWeeklySchedule();
    const dayMap = ['domingo', 'segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado'];
    const todayKey = dayMap[new Date().getDay()];

    const dayKeys = ['segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado', 'domingo'];

    pillsContainer.innerHTML = dayKeys.map(key => {
      const day = schedule[key];
      const isSelected = key === this.selectedDayKey;
      const isToday = key === todayKey;
      const subLabel = day.isRest ? 'Descanso' : (day.title ? day.title.split('-')[0].trim() : 'Treino');

      return `
        <div class="day-tab-btn ${isSelected ? 'active' : ''}" onclick="window.AtlasWorkout.selectDay('${key}')">
          ${isToday ? '<span class="day-today-tag">HOJE</span>' : ''}
          <span class="day-tab-name">${day.shortName}</span>
          <span class="day-tab-sub">${subLabel}</span>
        </div>
      `;
    }).join('');

    this.renderSelectedDayDetails();
  },

  selectDay(dayKey) {
    this.selectedDayKey = dayKey;
    this.renderWeekSchedule();
  },

  renderSelectedDayDetails() {
    const container = document.getElementById('selected-day-details-container');
    if (!container) return;

    const schedule = AtlasDB.getWeeklySchedule();
    const day = schedule[this.selectedDayKey];
    if (!day) return;

    if (day.isRest) {
      container.innerHTML = `
        <div style="background:var(--bg-surface-elevated); border:1px solid var(--border-subtle); border-radius:var(--radius-lg); padding:32px 24px; text-align:center;">
          <div style="font-size:2.8rem; margin-bottom:12px;">🌿</div>
          <h4 style="font-size:1.35rem; font-weight:900; color:#FFFFFF; margin-bottom:6px;">${day.dayName}: ${day.title}</h4>
          <span style="display:inline-block; background:var(--primary-subtle); color:var(--primary); border:1px solid var(--primary-border); border-radius:var(--radius-full); padding:4px 16px; font-size:0.78rem; font-weight:800; margin-bottom:18px; letter-spacing:0.5px;">
            Descanso Ativo / Recuperação Celular
          </span>
          <p style="color:var(--text-secondary); font-size:0.9rem; max-width:560px; margin:0 auto 22px; line-height:1.6;">
            A reconstrução das microfibras musculares e hipertrofia ocorrem na fase de sono e repouso. Mantenha hidratação constante, mobilidade leve e ingestão equilibrada de micronutrientes.
          </p>
          <div style="display:flex; justify-content:center; gap:12px; flex-wrap:wrap;">
            <button class="btn btn-secondary btn-sm" onclick="window.AtlasWorkout.toggleRestForSelectedDay(false)">
              🏋️ Alterar para Dia de Treino
            </button>
            <button class="btn btn-secondary btn-sm" onclick="window.AtlasApp.navigateTo('cardio')">
              🏃 Fazer Cardio Leve
            </button>
          </div>
        </div>
      `;
      return;
    }

    const exList = day.exercises || [];

    let exercisesHtml = '';
    if (exList.length === 0) {
      exercisesHtml = `
        <div style="background:rgba(9,13,22,0.8); border:1px dashed var(--primary-border); border-radius:var(--radius-md); padding:28px; text-align:center;">
          <p style="color:var(--text-secondary); font-size:0.92rem; margin-bottom:14px;">
            Nenhum exercício montado para <strong>${day.dayName}</strong> ainda.
          </p>
          <button class="btn btn-primary btn-sm" onclick="window.AtlasWorkout.openAddToDayModal()">
            ➕ Adicionar Primeiro Exercício
          </button>
        </div>
      `;
    } else {
      exercisesHtml = exList.map((ex, idx) => `
        <div class="card" style="padding:16px 20px; margin-bottom:12px; display:flex; align-items:center; justify-content:space-between; gap:16px; background:rgba(12,18,30,0.85); border:1px solid var(--border-glass); box-shadow:var(--shadow-sm);">
          <img src="${ex.image || 'assets/logo.jpg'}" alt="${ex.name}" style="width:58px; height:58px; border-radius:var(--radius-md); object-fit:cover; border:1.5px solid var(--primary-border); box-shadow:0 0 12px rgba(16,245,122,0.2);">
          <div style="flex:1;">
            <div style="display:flex; align-items:center; gap:8px;">
              <span style="font-size:0.75rem; background:linear-gradient(135deg, rgba(16,245,122,0.2) 0%, rgba(0,229,255,0.2) 100%); color:var(--primary); font-weight:900; padding:2px 8px; border-radius:var(--radius-sm); border:1px solid var(--primary-border);">${idx + 1}</span>
              <h5 style="font-size:1.05rem; font-weight:800; color:#FFFFFF; letter-spacing:-0.2px;">${ex.name}</h5>
            </div>
            <p style="font-size:0.82rem; color:var(--primary); margin-top:3px; font-weight:700;">
              ${ex.sets} séries • ${ex.reps} repetições • Descanso: ${ex.restSeconds}s • Carga: ${ex.weight ? ex.weight + ' kg' : 'Corpo/Livre'}
            </p>
          </div>
          <button class="btn btn-danger btn-sm" style="padding:7px 12px;" onclick="window.AtlasWorkout.removeExerciseFromCurrentDay(${idx})" title="Remover deste dia">
            ✕
          </button>
        </div>
      `).join('');
    }

    container.innerHTML = `
      <div style="background:var(--grad-hud); border:1px solid var(--border-glass); border-radius:var(--radius-xl); padding:28px; box-shadow:var(--shadow-md);">
        <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:14px; margin-bottom:20px;">
          <div>
            <span style="font-size:0.75rem; color:var(--primary); font-weight:800; text-transform:uppercase; letter-spacing:1px; display:inline-flex; align-items:center; gap:6px;">
              <span class="status-dot"></span> ROTINA PROGRAMADA PARA ${day.dayName.toUpperCase()}
            </span>
            <h4 style="font-size:1.4rem; font-weight:900; color:#FFFFFF; margin-top:4px; letter-spacing:-0.3px;">${day.title}</h4>
            <p style="font-size:0.84rem; color:var(--text-secondary); margin-top:2px;">Foco: <strong style="color:#FFFFFF;">${day.focus || 'Geral'}</strong> (${exList.length} exercícios agendados)</p>
          </div>
          <button class="btn btn-primary" onclick="window.AtlasWorkout.startSelectedDayWorkout()">
            ⚡ Treinar Este Dia Agora
          </button>
        </div>

        <div>
          ${exercisesHtml}
        </div>
      </div>
    `;
  },

  startSelectedDayWorkout() {
    const schedule = AtlasDB.getWeeklySchedule();
    const day = schedule[this.selectedDayKey];

    if (!day || day.isRest || !day.exercises || day.exercises.length === 0) {
      alert(`O dia selecionado (${day.dayName}) está marcado como descanso ou não possui exercícios. Adicione exercícios antes de iniciar.`);
      return;
    }

    this.activeWorkout = {
      name: `${day.dayName} - ${day.title}`,
      exercises: day.exercises
    };
    this.loadExerciseToHud(0);

    // Rola a tela até o Live HUD do GymTrack
    document.querySelector('.workout-live-hud').scrollIntoView({ behavior: 'smooth' });
    window.AtlasApp.showStatusBanner(`Treino de ${day.dayName} carregado no Live HUD! Boa execução.`);
  },

  toggleRestForSelectedDay(isRest) {
    AtlasDB.saveDayWorkout(this.selectedDayKey, { isRest: isRest });
    this.renderWeekSchedule();
    window.AtlasApp.showStatusBanner(`${isRest ? 'Marcado como Descanso' : 'Marcado como Dia de Treino'} com sucesso!`);
  },

  openAddToDayModal() {
    const schedule = AtlasDB.getWeeklySchedule();
    const day = schedule[this.selectedDayKey];
    const exercises = AtlasDB.getExercises();

    const titleEl = document.getElementById('modal-add-to-day-title');
    if (titleEl) titleEl.textContent = `➕ Adicionar Exercício em ${day.dayName}`;

    const selectEl = document.getElementById('select-exercise-for-day');
    if (selectEl) {
      if (exercises.length === 0) {
        selectEl.innerHTML = `<option value="">Nenhum exercício no catálogo. Cadastre um primeiro.</option>`;
      } else {
        selectEl.innerHTML = exercises.map(ex => `
          <option value="${ex.id}">${ex.name} (${ex.category} - ${ex.sets}x${ex.reps})</option>
        `).join('');
      }
    }

    document.getElementById('modal-add-to-day').style.display = 'flex';
  },

  addExerciseToCurrentDay() {
    const exId = document.getElementById('select-exercise-for-day').value;
    const sets = parseInt(document.getElementById('day-ex-sets').value) || 3;
    const reps = parseInt(document.getElementById('day-ex-reps').value) || 10;
    const weight = parseFloat(document.getElementById('day-ex-weight').value) || null;
    const rest = parseInt(document.getElementById('day-ex-rest').value) || 60;

    const allExercises = AtlasDB.getExercises();
    const baseEx = allExercises.find(e => e.id === exId) || allExercises[0];

    if (!baseEx) {
      alert('Selecione um exercício válido.');
      return;
    }

    const newExForDay = {
      ...baseEx,
      sets: sets,
      reps: reps,
      weight: weight !== null ? weight : baseEx.weight,
      restSeconds: rest
    };

    AtlasDB.addExerciseToDay(this.selectedDayKey, newExForDay);
    this.renderWeekSchedule();
    document.getElementById('modal-add-to-day').style.display = 'none';
    window.AtlasApp.showStatusBanner(`"${newExForDay.name}" adicionado ao treino de ${this.selectedDayKey}!`);
  },

  removeExerciseFromCurrentDay(index) {
    AtlasDB.removeExerciseFromDay(this.selectedDayKey, index);
    this.renderWeekSchedule();
    window.AtlasApp.showStatusBanner('Exercício removido do treino deste dia.');
  },

  openEditDayModal() {
    const schedule = AtlasDB.getWeeklySchedule();
    const day = schedule[this.selectedDayKey];

    document.getElementById('modal-edit-day-title').textContent = `✏️ Configurar ${day.dayName}`;
    document.getElementById('edit-day-title').value = day.title || '';
    document.getElementById('edit-day-focus').value = day.focus || '';
    document.getElementById('edit-day-is-rest').checked = !!day.isRest;

    document.getElementById('modal-edit-day').style.display = 'flex';
  },

  saveEditedDay() {
    const title = document.getElementById('edit-day-title').value;
    const focus = document.getElementById('edit-day-focus').value;
    const isRest = document.getElementById('edit-day-is-rest').checked;

    AtlasDB.saveDayWorkout(this.selectedDayKey, {
      title: title,
      focus: focus,
      isRest: isRest
    });

    this.renderWeekSchedule();
    document.getElementById('modal-edit-day').style.display = 'none';
    window.AtlasApp.showStatusBanner(`Configuração de ${this.selectedDayKey} salva com sucesso!`);
  },

  // ==========================================================================
  // GYMTRACK LIVE HUD (ACOMPANHAMENTO EM TEMPO REAL)
  // ==========================================================================
  loadExerciseToHud(index) {
    if (!this.activeWorkout || !this.activeWorkout.exercises[index]) return;
    this.currentExerciseIndex = index;
    const ex = this.activeWorkout.exercises[index];
    this.currentSet = 1;
    this.currentReps = 0;
    this.restTimeTotal = ex.restSeconds || 60;

    document.getElementById('hud-exercise-name').textContent = ex.name;
    document.getElementById('hud-exercise-meta').textContent = `${ex.sets} séries • ${ex.reps} repetições • Carga: ${ex.weight ? ex.weight + ' kg' : 'Corpo'}`;
    document.getElementById('hud-current-set').textContent = `${this.currentSet}/${ex.sets}`;
    document.getElementById('hud-current-reps').textContent = `${this.currentReps}/${ex.reps}`;

    const imgEl = document.getElementById('hud-exercise-img');
    if (imgEl) {
      imgEl.src = ex.image || 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=500&auto=format&fit=crop&q=60';
      imgEl.alt = ex.name;
    }

    document.getElementById('hud-rest-timer-box').style.display = 'none';
  },

  incrementRep() {
    const ex = this.activeWorkout.exercises[this.currentExerciseIndex];
    if (this.currentReps < ex.reps) {
      this.currentReps++;
      document.getElementById('hud-current-reps').textContent = `${this.currentReps}/${ex.reps}`;
      this.playBeep(440, 0.08);

      if (this.currentReps === 1) {
        window.AtlasApp.showStatusBanner('Primeira repetição concluída! Mantenha a cadência.');
      } else if (this.currentReps === ex.reps) {
        window.AtlasApp.showStatusBanner('Repetições máximas da série atingidas! Conclua a série.');
      }
    }
  },

  completeSet() {
    const ex = this.activeWorkout.exercises[this.currentExerciseIndex];
    this.playBeep(660, 0.15);

    if (this.currentSet < ex.sets) {
      window.AtlasApp.showStatusBanner(`Série ${this.currentSet} finalizada! Iniciando descanso.`);
      this.currentSet++;
      this.currentReps = 0;
      document.getElementById('hud-current-set').textContent = `${this.currentSet}/${ex.sets}`;
      document.getElementById('hud-current-reps').textContent = `0/${ex.reps}`;
      this.startRestTimer(this.restTimeTotal);
    } else {
      window.AtlasApp.showStatusBanner(`Parabéns! Todas as ${ex.sets} séries de ${ex.name} foram concluídas!`);
      this.nextExercise();
    }
  },

  nextExercise() {
    if (this.currentExerciseIndex + 1 < this.activeWorkout.exercises.length) {
      this.loadExerciseToHud(this.currentExerciseIndex + 1);
      window.AtlasApp.showStatusBanner(`Próximo exercício: ${this.activeWorkout.exercises[this.currentExerciseIndex].name}`);
    } else {
      window.AtlasApp.showStatusBanner('🎉 Treino Completo Concluído com Sucesso!');
    }
  },

  startRestTimer(seconds) {
    this.stopRestTimer();
    const timerBox = document.getElementById('hud-rest-timer-box');
    const timerText = document.getElementById('hud-timer-sec');
    const circleProgress = document.getElementById('hud-timer-circle');

    timerBox.style.display = 'flex';
    this.restTimeRemaining = seconds;
    const total = seconds;
    const circumference = 2 * Math.PI * 70;

    const updateSvg = () => {
      const fraction = this.restTimeRemaining / total;
      const offset = circumference * (1 - fraction);
      circleProgress.style.strokeDashoffset = offset;
      timerText.textContent = `${this.restTimeRemaining}s`;
    };

    updateSvg();

    this.restTimerInterval = setInterval(() => {
      this.restTimeRemaining--;
      if (this.restTimeRemaining <= 0) {
        this.stopRestTimer();
        this.playBeep(880, 0.4);
        window.AtlasApp.showStatusBanner('Tempo de descanso finalizado! Prepare-se para a próxima série.');
      } else {
        updateSvg();
      }
    }, 1000);
  },

  stopRestTimer() {
    if (this.restTimerInterval) {
      clearInterval(this.restTimerInterval);
      this.restTimerInterval = null;
    }
    const timerBox = document.getElementById('hud-rest-timer-box');
    if (timerBox) timerBox.style.display = 'none';
  },

  playBeep(freq = 520, duration = 0.1) {
    try {
      const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + duration);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + duration);
    } catch (e) {
      console.log('Audio Context muted.');
    }
  },

  renderExerciseList() {
    const listContainer = document.getElementById('exercise-card-list');
    if (!listContainer) return;

    const exercises = AtlasDB.getExercises();
    if (exercises.length === 0) {
      listContainer.innerHTML = `<p style="color:var(--text-muted); padding:20px;">Nenhum exercício cadastrado ainda.</p>`;
      return;
    }

    listContainer.innerHTML = exercises.map((ex, i) => `
      <div class="card" style="padding:16px 20px; margin-bottom:12px; display:flex; align-items:center; justify-content:space-between; gap:16px; background:rgba(12,18,30,0.85); border:1px solid var(--border-glass); box-shadow:var(--shadow-sm);">
        <img src="${ex.image || 'assets/logo.jpg'}" alt="${ex.name}" style="width:64px; height:64px; border-radius:var(--radius-md); object-fit:cover; border:1.5px solid var(--primary-border); box-shadow:0 0 12px rgba(16,245,122,0.18);">
        <div style="flex:1;">
          <h4 style="font-size:1.05rem; font-weight:800; color:#FFFFFF; letter-spacing:-0.2px;">${ex.name}</h4>
          <span style="font-size:0.8rem; color:var(--primary); font-weight:700;">${ex.category} • ${ex.sets} séries x ${ex.reps} reps • Descanso: ${ex.restSeconds}s</span>
          <p style="font-size:0.75rem; color:var(--text-muted); margin-top:4px;">Carga: <strong style="color:#FFFFFF;">${ex.weight ? ex.weight + ' kg' : 'Sem peso'}</strong> | ${ex.equipment || 'Livre'}</p>
        </div>
        <div style="display:flex; gap:8px;">
          <button class="btn btn-primary btn-sm" onclick="window.AtlasWorkout.selectForLive(${i})">Treinar</button>
          <button class="btn btn-danger btn-sm" onclick="window.AtlasWorkout.deleteExercise('${ex.id}')">Excluir</button>
        </div>
      </div>
    `).join('');
  },

  selectForLive(index) {
    const exercises = AtlasDB.getExercises();
    this.activeWorkout = {
      name: exercises[index].name,
      exercises: [exercises[index]]
    };
    this.loadExerciseToHud(0);
    window.location.hash = '#workout';
    document.querySelector('.workout-live-hud').scrollIntoView({ behavior: 'smooth' });
    window.AtlasApp.showStatusBanner(`Exercício ativo no HUD: ${exercises[index].name}`);
  },

  deleteExercise(id) {
    AtlasDB.deleteExercise(id);
    this.renderExerciseList();
    this.renderWeekSchedule();
    window.AtlasApp.showStatusBanner('Exercício removido do seu catálogo.');
  },

  saveNewExercise() {
    const name = document.getElementById('ex-name').value;
    const category = document.getElementById('ex-category').value;
    const sets = parseInt(document.getElementById('ex-sets').value) || 3;
    const reps = parseInt(document.getElementById('ex-reps').value) || 10;
    const rest = parseInt(document.getElementById('ex-rest').value) || 60;
    const weight = parseFloat(document.getElementById('ex-weight').value) || null;
    const equipment = document.getElementById('ex-equipment').value || '';
    const image = document.getElementById('ex-image').value || 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=500&auto=format&fit=crop&q=60';

    if (!name) {
      alert('Informe o nome do exercício.');
      return;
    }

    AtlasDB.saveExercise({ name, category, sets, reps, restSeconds: rest, weight, equipment, image });
    this.renderExerciseList();
    document.getElementById('form-add-exercise').reset();
    document.getElementById('modal-add-exercise').style.display = 'none';
    window.AtlasApp.showStatusBanner(`Exercício "${name}" salvo com sucesso!`);
  },

  generateAiWorkout() {
    const days = parseInt(document.getElementById('ai-days-select').value) || 3;
    const goal = document.getElementById('ai-goal-select').value || 'Hipertrofia';
    const resultBox = document.getElementById('ai-workout-result');

    resultBox.innerHTML = `
      <div style="padding:28px; text-align:center;">
        <div class="status-dot" style="margin:0 auto 12px; width:12px; height:12px;"></div>
        <p style="color:var(--primary); font-weight:800; letter-spacing:0.3px;">Atlas AI calculando periodização científica para ${days} dias (${goal})...</p>
      </div>
    `;

    setTimeout(() => {
      let routineHtml = '';
      if (days === 3) {
        routineHtml = `
          <h4 style="color:#FFFFFF; font-size:1.2rem; font-weight:900; margin-bottom:14px; letter-spacing:-0.2px;">📋 Rotina Iniciante ABC (3 Dias na Semana)</h4>
          <div style="background:rgba(12, 18, 30, 0.9); border:1px solid var(--border-glass); border-left:3.5px solid var(--primary); padding:16px 18px; border-radius:var(--radius-md); margin-bottom:12px; box-shadow:var(--shadow-sm);">
            <p style="color:var(--primary); font-weight:800; font-size:0.96rem;">Segunda-feira - Peito, Deltoide Anterior e Tríceps</p>
            <p style="color:var(--text-secondary); font-size:0.86rem; margin-top:4px; line-height:1.5;">Supino Reto 3x10, Crucifixo 3x12, Desenvolvimento com Halteres 3x10, Tríceps Corda 3x12.</p>
          </div>
          <div style="background:rgba(12, 18, 30, 0.9); border:1px solid var(--border-glass); border-left:3.5px solid var(--secondary); padding:16px 18px; border-radius:var(--radius-md); margin-bottom:12px; box-shadow:var(--shadow-sm);">
            <p style="color:var(--secondary); font-weight:800; font-size:0.96rem;">Quarta-feira - Costas, Deltoide Posterior e Bíceps</p>
            <p style="color:var(--text-secondary); font-size:0.86rem; margin-top:4px; line-height:1.5;">Puxada Frontal na Polia 3x10, Remada Baixa 3x10, Crucifixo Inverso 3x12, Rosca Direta 3x10.</p>
          </div>
          <div style="background:rgba(12, 18, 30, 0.9); border:1px solid var(--border-glass); border-left:3.5px solid var(--accent-purple); padding:16px 18px; border-radius:var(--radius-md); margin-bottom:12px; box-shadow:var(--shadow-sm);">
            <p style="color:#C084FC; font-weight:800; font-size:0.96rem;">Sexta-feira - Pernas Completas e Abdômen</p>
            <p style="color:var(--text-secondary); font-size:0.86rem; margin-top:4px; line-height:1.5;">Leg Press 45º 4x12, Cadeira Extensora 3x12, Mesa Flexora 3x12, Panturrilha 4x15, Abdominal 3x15.</p>
          </div>
        `;
      } else if (days === 4) {
        routineHtml = `
          <h4 style="color:#FFFFFF; font-size:1.2rem; font-weight:900; margin-bottom:14px; letter-spacing:-0.2px;">📋 Rotina Iniciante Upper/Lower (4 Dias)</h4>
          <div style="background:rgba(12, 18, 30, 0.9); border:1px solid var(--border-glass); border-left:3.5px solid var(--primary); padding:16px 18px; border-radius:var(--radius-md); margin-bottom:12px;">
            <p style="color:var(--primary); font-weight:800; font-size:0.96rem;">Segunda & Quinta: Superiores (Upper Body)</p>
            <p style="color:var(--text-secondary); font-size:0.86rem; margin-top:4px;">Supino Reto 3x10, Puxada Alta 3x10, Elevação Lateral 3x12, Rosca Scott 3x10, Tríceps Testa 3x10.</p>
          </div>
          <div style="background:rgba(12, 18, 30, 0.9); border:1px solid var(--border-glass); border-left:3.5px solid var(--secondary); padding:16px 18px; border-radius:var(--radius-md); margin-bottom:12px;">
            <p style="color:var(--secondary); font-weight:800; font-size:0.96rem;">Terça & Sexta: Inferiores (Lower Body)</p>
            <p style="color:var(--text-secondary); font-size:0.86rem; margin-top:4px;">Agachamento Guiado 4x10, Cadeira Flexora 3x12, Cadeira Adutora 3x15, Gêmeos em Pé 4x15.</p>
          </div>
        `;
      } else {
        routineHtml = `
          <h4 style="color:#FFFFFF; font-size:1.2rem; font-weight:900; margin-bottom:14px; letter-spacing:-0.2px;">📋 Rotina Iniciante PPL (Push / Pull / Legs - 5 Dias)</h4>
          <p style="color:var(--text-secondary); font-size:0.88rem; line-height:1.5;">Divisão de 5 dias calibrada com descanso ativo na quarta e no domingo.</p>
        `;
      }

      routineHtml += `
        <button class="btn btn-primary" style="margin-top:16px; width:100%;" onclick="window.AtlasWorkout.applyAiRoutineToWeek(${days})">
          ⚡ Aplicar Esta Rotina Automaticamente no Meu Cronograma Semanal
        </button>
      `;

      resultBox.innerHTML = routineHtml;
    }, 600);
  },

  applyAiRoutineToWeek(days) {
    const allEx = AtlasDB.getExercises();
    const peito = allEx.filter(e => e.category === 'Peito');
    const costas = allEx.filter(e => e.category === 'Costas');
    const pernas = allEx.filter(e => e.category === 'Pernas');
    const ombros = allEx.filter(e => e.category === 'Ombros');

    if (days === 3) {
      AtlasDB.saveDayWorkout('segunda', { title: 'Treino A - Peito e Tríceps', focus: 'Superiores (Empurrar)', isRest: false, exercises: peito });
      AtlasDB.saveDayWorkout('terca', { title: 'Descanso Ativo ou Cardio', focus: 'Recuperação', isRest: true, exercises: [] });
      AtlasDB.saveDayWorkout('quarta', { title: 'Treino B - Costas e Bíceps', focus: 'Superiores (Puxar)', isRest: false, exercises: costas });
      AtlasDB.saveDayWorkout('quinta', { title: 'Descanso Ativo ou Cardio', focus: 'Recuperação', isRest: true, exercises: [] });
      AtlasDB.saveDayWorkout('sexta', { title: 'Treino C - Pernas e Abdômen', focus: 'Inferiores Completo', isRest: false, exercises: pernas });
      AtlasDB.saveDayWorkout('sabado', { title: 'Cardio ou Descanso', focus: 'Recuperação', isRest: true, exercises: [] });
      AtlasDB.saveDayWorkout('domingo', { title: 'Descanso Total', focus: 'Regeneração', isRest: true, exercises: [] });
    }

    this.renderWeekSchedule();
    window.AtlasApp.showStatusBanner('✨ Rotina gerada pela IA distribuída por todos os dias da semana!');
  }
};
