// ==========================================================================
// ATLAS - MÓDULO DE CARDIO COM RASTREAMENTO EM SEGUNDO PLANO
// ==========================================================================
import { AtlasDB } from '../firebase-config.js';

export const CardioModule = {
  worker: null,
  wakeLock: null,
  isRunning: false,
  activityType: 'Corrida ao Ar Livre',
  totalSeconds: 0,
  distanceKm: 0,
  caloriesBurned: 0,
  watchPositionId: null,
  simulatedSpeedKmH: 9.5, // ~6:18 min/km

  init() {
    this.initWorker();
    this.setupListeners();
    this.renderHistory();
  },

  initWorker() {
    try {
      this.worker = new Worker('js/workers/cardio-worker.js');
      this.worker.onmessage = (e) => this.handleWorkerMessage(e.data);
    } catch (err) {
      console.warn('Web Worker não pôde ser iniciado em modo estrito, usando timer fallback:', err);
    }
  },

  setupListeners() {
    const startBtn = document.getElementById('cardio-btn-start');
    const pauseBtn = document.getElementById('cardio-btn-pause');
    const stopBtn = document.getElementById('cardio-btn-stop');
    const typeSelect = document.getElementById('cardio-type-select');

    if (startBtn) startBtn.addEventListener('click', () => this.startSession());
    if (pauseBtn) pauseBtn.addEventListener('click', () => this.pauseSession());
    if (stopBtn) stopBtn.addEventListener('click', () => this.finishSession());
    if (typeSelect) {
      typeSelect.addEventListener('change', (e) => {
        this.activityType = e.target.value;
        if (this.activityType.includes('Caminhada')) {
          this.simulatedSpeedKmH = 5.2;
        } else if (this.activityType.includes('Ciclismo')) {
          this.simulatedSpeedKmH = 21.0;
        } else {
          this.simulatedSpeedKmH = 9.8;
        }
      });
    }
  },

  async requestWakeLock() {
    if ('wakeLock' in navigator) {
      try {
        this.wakeLock = await navigator.wakeLock.request('screen');
        console.log('[Atlas Cardio] Wake Lock ativado: tela permanecerá ligada durante a corrida.');
      } catch (err) {
        console.log('[Atlas Cardio] Wake Lock não pôde ser adquirido:', err);
      }
    }
  },

  releaseWakeLock() {
    if (this.wakeLock) {
      this.wakeLock.release().then(() => {
        this.wakeLock = null;
      });
    }
  },

  startSession() {
    this.isRunning = true;
    this.requestWakeLock();

    document.getElementById('cardio-btn-start').style.display = 'none';
    document.getElementById('cardio-btn-pause').style.display = 'inline-flex';
    document.getElementById('cardio-btn-stop').style.display = 'inline-flex';
    document.getElementById('cardio-live-status-pill').textContent = '● GRAVANDO EM SEGUNDO PLANO';
    document.getElementById('cardio-live-status-pill').style.color = 'var(--primary)';

    if (this.worker) {
      this.worker.postMessage({ action: 'START' });
    }

    window.AtlasApp.showStatusBanner(`Sessão de ${this.activityType} iniciada! O rastreamento continua em segundo plano.`);
  },

  pauseSession() {
    this.isRunning = false;
    document.getElementById('cardio-btn-start').style.display = 'inline-flex';
    document.getElementById('cardio-btn-start').textContent = 'Continuar';
    document.getElementById('cardio-btn-pause').style.display = 'none';
    document.getElementById('cardio-live-status-pill').textContent = '⏸ PAUSADO';
    document.getElementById('cardio-live-status-pill').style.color = 'var(--energy-amber)';

    if (this.worker) {
      this.worker.postMessage({ action: 'PAUSE' });
    }
  },

  handleWorkerMessage(data) {
    if (data.type === 'TICK') {
      this.totalSeconds = data.totalSeconds;
      this.updateMetrics();
    }
  },

  updateMetrics() {
    const hours = Math.floor(this.totalSeconds / 3600);
    const minutes = Math.floor((this.totalSeconds % 3600) / 60);
    const seconds = this.totalSeconds % 60;
    const timeFormatted = `${hours > 0 ? String(hours).padStart(2, '0') + ':' : ''}${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

    // Cálculo da distância baseado na velocidade média e tempo
    const hoursFraction = this.totalSeconds / 3600;
    this.distanceKm = (this.simulatedSpeedKmH * hoursFraction);
    
    // Ritmo (Pace) em min/km
    let paceFormatted = '0:00';
    if (this.distanceKm > 0.05) {
      const paceMinutes = (this.totalSeconds / 60) / this.distanceKm;
      const paceM = Math.floor(paceMinutes);
      const paceS = Math.floor((paceMinutes - paceM) * 60);
      paceFormatted = `${paceM}:${String(paceS).padStart(2, '0')}`;
    }

    // Calorias estimadas (MET ~ 8.5 para corrida, 3.8 para caminhada * peso 75kg * horas)
    const user = AtlasDB.getCurrentUser();
    const weight = user ? user.weight : 75;
    const met = this.activityType.includes('Caminhada') ? 3.8 : 8.8;
    this.caloriesBurned = Math.round(met * weight * hoursFraction);

    // Atualização da UI em tempo real
    document.getElementById('cardio-time-val').textContent = timeFormatted;
    document.getElementById('cardio-distance-val').textContent = this.distanceKm.toFixed(2);
    document.getElementById('cardio-pace-val').textContent = paceFormatted;
    document.getElementById('cardio-calories-val').textContent = this.caloriesBurned;
  },

  finishSession() {
    this.isRunning = false;
    this.releaseWakeLock();

    if (this.worker) {
      this.worker.postMessage({ action: 'RESET' });
    }

    if (this.totalSeconds > 10) {
      const sessionData = {
        type: this.activityType,
        distanceKm: parseFloat(this.distanceKm.toFixed(2)),
        durationMin: Math.round(this.totalSeconds / 60) || 1,
        paceMinKm: document.getElementById('cardio-pace-val').textContent,
        calories: this.caloriesBurned
      };
      AtlasDB.saveCardioSession(sessionData);
      window.AtlasApp.showStatusBanner(`Corrida salva! ${sessionData.distanceKm} km concluídos.`);
    }

    // Reset UI
    this.totalSeconds = 0;
    this.distanceKm = 0;
    this.caloriesBurned = 0;
    document.getElementById('cardio-time-val').textContent = '00:00';
    document.getElementById('cardio-distance-val').textContent = '0.00';
    document.getElementById('cardio-pace-val').textContent = '0:00';
    document.getElementById('cardio-calories-val').textContent = '0';
    document.getElementById('cardio-btn-start').style.display = 'inline-flex';
    document.getElementById('cardio-btn-start').textContent = 'Iniciar Treino';
    document.getElementById('cardio-btn-pause').style.display = 'none';
    document.getElementById('cardio-btn-stop').style.display = 'none';
    document.getElementById('cardio-live-status-pill').textContent = '● PRONTO PARA INICIAR';
    document.getElementById('cardio-live-status-pill').style.color = 'var(--text-muted)';

    this.renderHistory();
  },

  renderHistory() {
    const container = document.getElementById('cardio-history-list');
    if (!container) return;

    const history = AtlasDB.getCardioHistory();
    if (history.length === 0) {
      container.innerHTML = `<p style="color:var(--text-muted); padding:16px;">Nenhum treino de cardio registrado ainda.</p>`;
      return;
    }

    container.innerHTML = history.map(item => `
      <div style="background:var(--surface-card); border:1px solid var(--border-glass); border-radius:var(--radius-md); padding:16px 20px; margin-bottom:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:14px; box-shadow:var(--shadow-sm); backdrop-filter:blur(12px);">
        <div>
          <span style="font-size:0.72rem; color:var(--text-muted); font-weight:700; text-transform:uppercase; letter-spacing:0.8px;">${item.date}</span>
          <h4 style="font-size:1.05rem; font-weight:900; color:var(--text-primary); margin-top:2px; letter-spacing:-0.2px; font-family:var(--font-heading); margin-bottom:0;">${item.type}</h4>
        </div>
        <div style="display:flex; gap:18px; align-items:center;">
          <div style="text-align:right;">
            <div style="font-size:1.25rem; font-weight:900; color:var(--primary); font-family:var(--font-heading);">${item.distanceKm} <span style="font-size:0.8rem; color:var(--text-secondary); font-weight:700;">km</span></div>
            <div style="font-size:0.78rem; color:var(--text-secondary); font-weight:600;">${item.durationMin} min • Pace ${item.paceMinKm}</div>
          </div>
          <div style="background:rgba(255, 71, 87, 0.12); color:var(--energy-coral); border:1px solid rgba(255, 71, 87, 0.3); padding:6px 14px; border-radius:var(--radius-sm); font-size:0.82rem; font-weight:900;">
            🔥 ${item.calories} kcal
          </div>
        </div>
      </div>
    `).join('');
  }
};
