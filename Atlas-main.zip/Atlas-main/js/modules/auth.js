// ==========================================================================
// ATLAS - MÓDULO DE AUTENTICAÇÃO & PERFIL (AUTH ENGINE)
// ==========================================================================
import { AtlasDB, isFirebaseConfigured } from '../firebase-config.js';

export const AuthModule = {
  init() {
    this.setupListeners();
    this.renderUserProfile();
  },

  setupListeners() {
    const loginForm = document.getElementById('form-login');
    const registerForm = document.getElementById('form-register');
    const profileForm = document.getElementById('form-profile-settings');

    if (loginForm) {
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleLogin();
      });
    }

    if (registerForm) {
      registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleRegister();
      });
    }

    if (profileForm) {
      profileForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleUpdateProfile();
      });
    }

    // Botões para alternar modais de login / registro
    const showRegisterLink = document.getElementById('link-show-register');
    const showLoginLink = document.getElementById('link-show-login');
    if (showRegisterLink) {
      showRegisterLink.addEventListener('click', () => {
        document.getElementById('modal-login-view').style.display = 'none';
        document.getElementById('modal-register-view').style.display = 'block';
      });
    }
    if (showLoginLink) {
      showLoginLink.addEventListener('click', () => {
        document.getElementById('modal-register-view').style.display = 'none';
        document.getElementById('modal-login-view').style.display = 'block';
      });
    }
    // Ouvintes para cálculo de IMC em tempo real no Login
    const loginHeight = document.getElementById('login-height');
    const loginWeight = document.getElementById('login-weight');
    const updateLoginImc = () => {
      const h = parseFloat(loginHeight?.value) || 0;
      const w = parseFloat(loginWeight?.value) || 0;
      const badge = document.getElementById('login-imc-badge');
      if (badge) badge.innerHTML = this.formatImcBadge(w, h);
    };
    if (loginHeight) loginHeight.addEventListener('input', updateLoginImc);
    if (loginWeight) loginWeight.addEventListener('input', updateLoginImc);

    // Ouvintes para cálculo de IMC em tempo real no Cadastro
    const regHeight = document.getElementById('reg-height');
    const regWeight = document.getElementById('reg-weight');
    const updateRegImc = () => {
      const h = parseFloat(regHeight?.value) || 0;
      const w = parseFloat(regWeight?.value) || 0;
      const badge = document.getElementById('reg-imc-badge');
      if (badge) badge.innerHTML = this.formatImcBadge(w, h);
    };
    if (regHeight) regHeight.addEventListener('input', updateRegImc);
    if (regWeight) regWeight.addEventListener('input', updateRegImc);
  },

  formatImcBadge(weight, heightCm) {
    if (heightCm <= 0 || weight <= 0) return '';
    const heightM = heightCm / 100;
    const imc = (weight / (heightM * heightM)).toFixed(1);
    let classif = 'Eutrofia / Peso Normal';
    let color = 'var(--primary)';

    if (imc < 18.5) {
      classif = 'Abaixo do peso ideal';
      color = 'var(--secondary)';
    } else if (imc >= 25 && imc < 30) {
      classif = 'Sobrepeso leve (Ideal para recomposição)';
      color = 'var(--energy-amber)';
    } else if (imc >= 30) {
      classif = 'Grau de sobrepeso acentuado';
      color = 'var(--energy-coral)';
    }

    return `<span style="color:${color}; font-weight:800; display:inline-flex; align-items:center; gap:6px;">⚡ IMC Estimado: ${imc} kg/m² (${classif})</span>`;
  },

  renderUserProfile() {
    const user = AtlasDB.getCurrentUser();
    if (!user) return;

    // Atualiza avatares e nomes em toda a interface
    const avatarEls = document.querySelectorAll('.user-avatar-text');
    avatarEls.forEach(el => el.textContent = user.avatarText || 'AT');

    const nameEls = document.querySelectorAll('.user-display-name');
    nameEls.forEach(el => el.textContent = user.name || 'Usuário Atlas');

    const emailEls = document.querySelectorAll('.user-display-email');
    emailEls.forEach(el => el.textContent = user.email || 'usuario@atlas.fit');

    // Preenche formulário de perfil
    const nameInput = document.getElementById('profile-name');
    const weightInput = document.getElementById('profile-weight');
    const heightInput = document.getElementById('profile-height');
    const goalInput = document.getElementById('profile-goal');

    if (nameInput) nameInput.value = user.name || '';
    if (weightInput) weightInput.value = user.weight || '';
    if (heightInput) heightInput.value = user.height || '';
    if (goalInput) goalInput.value = user.goal || 'Hipertrofia e Definição';

    // Preenche campos do modal de login com os dados salvos
    const loginHeight = document.getElementById('login-height');
    const loginWeight = document.getElementById('login-weight');
    if (loginHeight && user.height) loginHeight.value = user.height;
    if (loginWeight && user.weight) loginWeight.value = user.weight;
  },

  handleLogin() {
    const email = document.getElementById('login-email').value;
    const pass = document.getElementById('login-password').value;
    const height = parseFloat(document.getElementById('login-height')?.value);
    const weight = parseFloat(document.getElementById('login-weight')?.value);

    if (!email || !pass) {
      alert('Preencha seu e-mail e senha de acesso.');
      return;
    }

    if (!height || !weight || height <= 50 || weight <= 20) {
      alert('Por favor, informe uma altura e peso válidos para calibrar a IA do Atlas.');
      return;
    }

    const heightM = height / 100;
    const imc = (weight / (heightM * heightM)).toFixed(1);

    const user = {
      uid: 'u_' + Date.now(),
      name: email.split('@')[0].toUpperCase(),
      email: email,
      avatarText: email.substring(0, 2).toUpperCase(),
      weight: weight,
      height: height,
      imc: imc,
      goal: 'Hipertrofia e Definição'
    };

    AtlasDB.saveCurrentUser(user);
    this.renderUserProfile();
    
    // Recalcula nutrição na hora com os novos dados de peso/altura
    if (window.AtlasHealth) {
      window.AtlasHealth.updateDietRecommendations();
    }

    document.getElementById('modal-auth').style.display = 'none';
    window.AtlasApp.showStatusBanner(`Login realizado! Perfil calibrado: ${height}cm | ${weight}kg (IMC: ${imc})`);
  },

  handleRegister() {
    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const pass = document.getElementById('reg-password').value;
    const height = parseFloat(document.getElementById('reg-height').value);
    const weight = parseFloat(document.getElementById('reg-weight').value);
    const goal = document.getElementById('reg-goal').value || 'Hipertrofia e Definição';

    if (!name || !email || !pass) {
      alert('Por favor, preencha nome, e-mail e senha.');
      return;
    }

    if (!height || !weight || height <= 50 || weight <= 20) {
      alert('A altura e o peso são obrigatórios para a personalização das fichas de treino e nutrição.');
      return;
    }

    const heightM = height / 100;
    const imc = (weight / (heightM * heightM)).toFixed(1);
    const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();

    const user = {
      uid: 'u_' + Date.now(),
      name: name,
      email: email,
      avatarText: initials,
      weight: weight,
      height: height,
      imc: imc,
      goal: goal
    };

    AtlasDB.saveCurrentUser(user);
    this.renderUserProfile();

    if (window.AtlasHealth) {
      window.AtlasHealth.updateDietRecommendations();
    }

    document.getElementById('modal-auth').style.display = 'none';
    window.AtlasApp.showStatusBanner(`Conta criada com sucesso! Bem-vindo, ${name} (${height}cm | ${weight}kg)`);
  },

  handleUpdateProfile() {
    const user = AtlasDB.getCurrentUser() || {};
    user.name = document.getElementById('profile-name').value;
    user.weight = parseFloat(document.getElementById('profile-weight').value) || user.weight;
    user.height = parseFloat(document.getElementById('profile-height').value) || user.height;
    user.goal = document.getElementById('profile-goal').value;

    if (user.height && user.weight) {
      const heightM = user.height / 100;
      user.imc = (user.weight / (heightM * heightM)).toFixed(1);
    }

    AtlasDB.saveCurrentUser(user);
    this.renderUserProfile();

    if (window.AtlasHealth) {
      window.AtlasHealth.updateDietRecommendations();
    }

    window.AtlasApp.showStatusBanner(`Perfil atualizado! Altura: ${user.height}cm | Peso: ${user.weight}kg`);
  }
};
