// ==========================================================================
// ATLAS - MÓDULO DE LOJA, SUPLEMENTOS & EQUIPAMENTOS
// ==========================================================================

export const ShopModule = {
  products: [
    {
      id: 'p_1',
      name: '100% Whey Concentrado 900g',
      category: 'suplementos',
      target: 'hipertrofia',
      level: 'iniciante',
      price: 'R$ 109,90',
      image: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?w=500&auto=format&fit=crop&q=60',
      desc: 'Proteína do soro do leite de alto valor biológico com 24g de proteína por dose.',
      link: 'https://www.google.com/search?q=whey+protein+concentrado'
    },
    {
      id: 'p_2',
      name: 'Creatina Monohidratada 100% Pura 300g',
      category: 'suplementos',
      target: 'forca',
      level: 'iniciante',
      price: 'R$ 89,90',
      image: 'https://images.unsplash.com/photo-1546483875-ad9014c88eba?w=500&auto=format&fit=crop&q=60',
      desc: 'Aumento de força e potência muscular com retenção hídrica intracelular.',
      link: 'https://www.google.com/search?q=creatina+monohidratada'
    },
    {
      id: 'p_3',
      name: 'Strap de Algodão Reforçado com Neoprene',
      category: 'equipamentos',
      target: 'forca',
      level: 'iniciante',
      price: 'R$ 39,90',
      image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=500&auto=format&fit=crop&q=60',
      desc: 'Auxilia na pegada em puxadas e levantamento terra, reduzindo a fadiga do antebraço.',
      link: 'https://www.google.com/search?q=strap+musculacao'
    },
    {
      id: 'p_4',
      name: 'Cinturão Lombar de Musculação em Couro',
      category: 'equipamentos',
      target: 'forca',
      level: 'avancado',
      price: 'R$ 149,00',
      image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=500&auto=format&fit=crop&q=60',
      desc: 'Estabilização da pressão intra-abdominal em agachamentos e terras pesados.',
      link: 'https://www.google.com/search?q=cinturao+musculacao+couro'
    },
    {
      id: 'p_5',
      name: 'Pré-Treino Ultra Concentrado (Beta-Alanina + Cafeína)',
      category: 'suplementos',
      target: 'energia',
      level: 'intermediario',
      price: 'R$ 119,00',
      image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?w=500&auto=format&fit=crop&q=60',
      desc: 'Foco mental aguçado, vasodilatação e redução da fadiga muscular imediata.',
      link: 'https://www.google.com/search?q=pre+treino+cafeina+beta+alanina'
    },
    {
      id: 'p_6',
      name: 'Garrafa Térmica Esportiva Inox 1L',
      category: 'equipamentos',
      target: 'hidratacao',
      level: 'iniciante',
      price: 'R$ 69,90',
      image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500&auto=format&fit=crop&q=60',
      desc: 'Mantém sua água gelada por até 24 horas durante as sessões de treino intenso.',
      link: 'https://www.google.com/search?q=garrafa+termica+inox+academia'
    }
  ],

  init() {
    this.renderProducts('all');
    this.setupListeners();
  },

  setupListeners() {
    const filterCategory = document.getElementById('shop-filter-category');
    if (filterCategory) {
      filterCategory.addEventListener('change', (e) => this.renderProducts(e.target.value));
    }

    const quizBtn = document.getElementById('btn-quiz-recommend');
    if (quizBtn) {
      quizBtn.addEventListener('click', () => this.runQuizRecommendation());
    }
  },

  renderProducts(categoryFilter = 'all') {
    const container = document.getElementById('shop-products-grid');
    if (!container) return;

    let filtered = this.products;
    if (categoryFilter !== 'all') {
      filtered = this.products.filter(p => p.category === categoryFilter);
    }

    container.innerHTML = filtered.map(p => `
      <div class="card" style="display:flex; flex-direction:column; justify-content:space-between; overflow:hidden; border:1px solid var(--border-glass);">
        <div>
          <div style="height:180px; border-radius:var(--radius-md); overflow:hidden; margin-bottom:16px; position:relative; box-shadow:var(--shadow-sm);">
            <img src="${p.image}" alt="${p.name}" style="width:100%; height:100%; object-fit:cover; transition:transform 0.4s ease;" onmouseover="this.style.transform='scale(1.06)'" onmouseout="this.style.transform='scale(1)'">
            <span style="position:absolute; top:10px; left:10px; background:rgba(7,10,15,0.85); backdrop-filter:blur(8px); -webkit-backdrop-filter:blur(8px); color:var(--primary); font-size:0.72rem; font-weight:800; padding:4px 10px; border-radius:var(--radius-sm); border:1px solid var(--border-accent); text-transform:uppercase; letter-spacing:0.8px;">
              ${p.category} • ${p.level}
            </span>
          </div>
          <h4 style="font-size:1.1rem; font-weight:900; color:var(--text-primary); margin-bottom:6px; letter-spacing:-0.2px; font-family:var(--font-heading);">${p.name}</h4>
          <p style="font-size:0.84rem; color:var(--text-secondary); line-height:1.5; margin-bottom:16px;">${p.desc}</p>
        </div>
        <div style="border-top:1px solid var(--border-subtle); padding-top:14px; margin-top:10px;">
          <div style="font-size:1.45rem; font-weight:900; color:var(--text-primary); margin-bottom:12px; letter-spacing:-0.3px; font-family:var(--font-heading);">
            <span class="gradient-text">${p.price}</span>
          </div>
          <a href="${p.link}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm" style="width:100%;">
            🛒 Onde Comprar com Melhor Preço
          </a>
        </div>
      </div>
    `).join('');
  },

  runQuizRecommendation() {
    const level = document.getElementById('quiz-user-level').value;
    const goal = document.getElementById('quiz-user-goal').value;
    const resultBox = document.getElementById('quiz-recommendation-result');

    resultBox.innerHTML = `
      <div style="padding:22px; background:var(--surface-card); border:1px solid var(--border-accent); border-radius:var(--radius-lg); box-shadow:var(--shadow-card); backdrop-filter:blur(16px); animation:fadeIn 0.25s ease;">
        <div style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
          <span style="color:var(--primary); font-size:1.2rem;">✨</span>
          <p style="color:var(--text-primary); font-weight:900; font-size:1.05rem; letter-spacing:-0.2px; font-family:var(--font-heading); margin:0;">Recomendação Personalizada Atlas AI:</p>
        </div>
        <p style="color:var(--text-secondary); font-size:0.9rem; line-height:1.6; margin:0;">
          ${level === 'iniciante' 
            ? 'Para quem está começando, evite gastar com termogênicos ou pré-treinos caros. Foque no que possui 100% de comprovação científica: <strong style="color:var(--primary);">Creatina Monohidratada 100% Pura</strong> diária (3g a 5g) para força e recuperação, combinada com <strong style="color:var(--text-primary);">100% Whey Concentrado</strong> caso tenha dificuldade em atingir sua meta proteica na alimentação.' 
            : 'Para elevar suas cargas com segurança articular, o investimento mais inteligente agora é um <strong style="color:var(--secondary);">Strap reforçado de Neoprene</strong> (evita que a fadiga das mãos limite o trabalho das costas) e um <strong style="color:var(--primary);">Cinturão Lombar de Couro</strong> para estabilização da coluna em agachamentos e levantamentos pesados.'}
        </p>
      </div>
    `;
  }
};
