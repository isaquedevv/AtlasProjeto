// ==========================================================================
// ATLAS - CONTROLADOR MESTRE DA APLICAÇÃO (SPA ENGINE)
// ==========================================================================
import { WorkoutModule } from './modules/workout.js';
import { HealthModule } from './modules/health.js';
import { ShopModule } from './modules/shop.js';
import { CardioModule } from './modules/cardio.js';
import { AuthModule } from './modules/auth.js';
import { AtlasDB } from './firebase-config.js';

class AtlasApplication {
  constructor() {
    this.currentView = 'dashboard';
  }

  init() {
    console.log('[Atlas App] Inicializando sistema...');

    // Inicialização dos Módulos
    AuthModule.init();
    WorkoutModule.init();
    HealthModule.init();
    ShopModule.init();
    CardioModule.init();

    // Exportação para o escopo global do navegador
    window.AtlasWorkout = WorkoutModule;
    window.AtlasHealth = HealthModule;
    window.AtlasShop = ShopModule;
    window.AtlasCardio = CardioModule;
    window.AtlasAuth = AuthModule;
    window.AtlasApp = this;

    this.setupNavigation();
    this.setupGlobalModals();
    this.handleInitialRoute();
    this.registerServiceWorker();
  }

  setupNavigation() {
    // Links de navegação Desktop e Mobile
    const navLinks = document.querySelectorAll('[data-view-target]');
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetView = link.getAttribute('data-view-target');
        this.navigateTo(targetView);

        // Fecha sidebar em mobile se estiver aberta
        const sidebar = document.getElementById('app-sidebar');
        if (sidebar) sidebar.classList.remove('mobile-open');
      });
    });

    // Botão menu mobile (hambúrguer)
    const mobileMenuBtn = document.getElementById('btn-mobile-menu');
    const sidebar = document.getElementById('app-sidebar');
    if (mobileMenuBtn && sidebar) {
      mobileMenuBtn.addEventListener('click', () => {
        sidebar.classList.toggle('mobile-open');
      });
    }

    // Sino de Notificações
    const notifBtn = document.getElementById('btn-notifications');
    const notifDropdown = document.getElementById('notifications-dropdown');
    if (notifBtn && notifDropdown) {
      notifBtn.addEventListener('click', () => {
        notifDropdown.style.display = notifDropdown.style.display === 'block' ? 'none' : 'block';
      });

      // Fechar ao clicar fora
      document.addEventListener('click', (e) => {
        if (!notifBtn.contains(e.target) && !notifDropdown.contains(e.target)) {
          notifDropdown.style.display = 'none';
        }
      });
    }
  }

  navigateTo(viewId) {
    this.currentView = viewId;
    window.location.hash = viewId;

    // Atualiza classes ativas nas seções
    const sections = document.querySelectorAll('.view-section');
    sections.forEach(s => s.classList.remove('active'));

    const activeSection = document.getElementById(`view-${viewId}`);
    if (activeSection) {
      activeSection.classList.add('active');
    }

    // Atualiza links da sidebar e bottom nav
    const navLinks = document.querySelectorAll('[data-view-target]');
    navLinks.forEach(link => {
      if (link.getAttribute('data-view-target') === viewId) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });

    // Atualiza título da página no cabeçalho
    const titles = {
      dashboard: { title: 'Visão Geral & Dashboard', subtitle: 'Acompanhe seu progresso e ritmo diário' },
      workout: { title: 'Módulo de Treino & Academia', subtitle: 'Acompanhamento em tempo real GymTrack e Gerador IA' },
      health: { title: 'Saúde, Nutrição & Alívio', subtitle: 'Orientações personalizadas e cuidados musculoesqueléticos' },
      shop: { title: 'Loja & Equipamentos', subtitle: 'Curadoria especializada em suplementação e acessórios' },
      cardio: { title: 'Cardio & GPS em Segundo Plano', subtitle: 'Rastreamento contínuo de caminhadas e corridas' },
      profile: { title: 'Minha Conta & Perfil', subtitle: 'Gerenciamento de dados antropométricos e segurança' },
      settings: { title: 'Configurações do Sistema', subtitle: 'Firebase, chaves de IA e preferências' }
    };

    if (titles[viewId]) {
      document.getElementById('header-page-title').textContent = titles[viewId].title;
      document.getElementById('header-page-subtitle').textContent = titles[viewId].subtitle;
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  handleInitialRoute() {
    const hash = window.location.hash.replace('#', '') || 'dashboard';
    this.navigateTo(hash);
  }

  showStatusBanner(message, duration = 4000) {
    const banner = document.getElementById('app-status-banner');
    const textEl = document.getElementById('status-banner-text');
    if (!banner || !textEl) return;

    textEl.textContent = message;
    banner.style.display = 'flex';

    if (this.bannerTimeout) clearTimeout(this.bannerTimeout);
    this.bannerTimeout = setTimeout(() => {
      banner.style.display = 'none';
    }, duration);
  }

  setupGlobalModals() {
    // Fechar modais ao clicar no X ou fora
    const closeBtns = document.querySelectorAll('[data-close-modal]');
    closeBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const modalId = btn.getAttribute('data-close-modal');
        const modal = document.getElementById(modalId);
        if (modal) modal.style.display = 'none';
      });
    });

    // Botão abrir modal novo exercício
    const openAddExBtn = document.getElementById('btn-open-add-ex');
    if (openAddExBtn) {
      openAddExBtn.addEventListener('click', () => {
        document.getElementById('modal-add-exercise').style.display = 'flex';
      });
    }

    // Botão abrir modal de autenticação
    const openAuthBtn = document.getElementById('btn-open-auth-modal');
    if (openAuthBtn) {
      openAuthBtn.addEventListener('click', () => {
        document.getElementById('modal-auth').style.display = 'flex';
      });
    }
  }

  registerServiceWorker() {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(err => {
        console.log('[Atlas SW] Service worker em ambiente local:', err);
      });
    }
  }
}

// Inicialização após o DOM carregar
document.addEventListener('DOMContentLoaded', () => {
  const app = new AtlasApplication();
  app.init();
});
