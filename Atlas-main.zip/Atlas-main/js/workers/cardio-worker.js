// Atlas Cardio Background Worker
let timerId = null;
let startTime = 0;
let accumulatedTime = 0;
let isRunning = false;

self.onmessage = function (e) {
  const { action, payload } = e.data;

  switch (action) {
    case 'START':
      if (!isRunning) {
        isRunning = true;
        startTime = Date.now();
        timerId = setInterval(tick, 1000);
      }
      break;

    case 'PAUSE':
      if (isRunning) {
        isRunning = false;
        clearInterval(timerId);
        accumulatedTime += Date.now() - startTime;
        self.postMessage({ type: 'STATUS', isRunning: false, totalSeconds: Math.floor(accumulatedTime / 1000) });
      }
      break;

    case 'RESUME':
      if (!isRunning) {
        isRunning = true;
        startTime = Date.now();
        timerId = setInterval(tick, 1000);
      }
      break;

    case 'RESET':
      isRunning = false;
      clearInterval(timerId);
      accumulatedTime = 0;
      self.postMessage({ type: 'RESET_COMPLETE', totalSeconds: 0 });
      break;
  }
};

function tick() {
  const currentSessionTime = Date.now() - startTime;
  const totalMs = accumulatedTime + currentSessionTime;
  const totalSeconds = Math.floor(totalMs / 1000);

  self.postMessage({
    type: 'TICK',
    totalSeconds: totalSeconds,
    timestamp: Date.now()
  });
}
