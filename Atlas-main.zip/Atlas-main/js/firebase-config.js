// ==========================================================================
// ATLAS - CONFIGURAÇÃO FIREBASE E CAMADA DE PERSISTÊNCIA DUAL
// ==========================================================================

/* 
  INSTRUÇÃO: Para conectar seu projeto real do Firebase:
  1. Acesse https://console.firebase.google.com/
  2. Crie um projeto e registre um aplicativo Web.
  3. Ative o "Authentication" (Provedor E-mail/Senha).
  4. Ative o "Cloud Firestore" (Modo Produção ou Teste).
  5. Substitua os valores abaixo pelas suas credenciais:
*/

export const firebaseConfig = {
  apiKey: "SUA_API_KEY_AQUI",
  authDomain: "seu-projeto-atlas.firebaseapp.com",
  projectId: "seu-projeto-atlas",
  storageBucket: "seu-projeto-atlas.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:0000000000000000000000"
};

// Detecção de credenciais válidas
export const isFirebaseConfigured = () => {
  return firebaseConfig.apiKey && firebaseConfig.apiKey !== "SUA_API_KEY_AQUI" && !firebaseConfig.apiKey.includes("SUA_");
};

// ==========================================================================
// ATLAS STORAGE ENGINE (Abstração unificada: Firestore OU LocalStorage)
// ==========================================================================
class AtlasStorageEngine {
  constructor() {
    this.mode = isFirebaseConfigured() ? 'FIREBASE' : 'LOCAL';
    console.log(`[Atlas Storage] Inicializado em modo: ${this.mode}`);
    this.initDefaultData();
  }

  // Dados iniciais de demonstração (caso o usuário teste offline)
  initDefaultData() {
    if (!localStorage.getItem('atlas_current_user')) {
      const defaultUser = {
        uid: 'user_demo_atlas',
        name: 'João Takeshita',
        email: 'joao@atlas.fit',
        avatarText: 'JT',
        weight: 78.5,
        height: 178,
        goal: 'Hipertrofia e Definição',
        level: 'Iniciante / Intermediário',
        notifications: [
          { id: '1', title: 'Bem-vindo ao Atlas!', message: 'Seu assistente de treino e saúde com IA está pronto.', time: 'Agora' },
          { id: '2', title: 'Treino de Hoje Sugerido', message: 'Divisão Peito & Tríceps configurada com descanso ativo.', time: 'Hoje' }
        ]
      };
      localStorage.setItem('atlas_current_user', JSON.stringify(defaultUser));
    }

    if (!localStorage.getItem('atlas_exercises')) {
      const defaultExercises = [
        {
          id: 'ex_1',
          name: 'Supino Reto com Barra',
          category: 'Peito',
          sets: 3,
          reps: 10,
          restSeconds: 60,
          weight: 60,
          image: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=500&auto=format&fit=crop&q=60',
          equipment: 'Banco e Barra Olímpica'
        },
        {
          id: 'ex_2',
          name: 'Puxada Frontal na Polia',
          category: 'Costas',
          sets: 3,
          reps: 12,
          restSeconds: 60,
          weight: 55,
          image: 'https://images.unsplash.com/photo-1605296867304-46d5465a13f1?w=500&auto=format&fit=crop&q=60',
          equipment: 'Polia Alta'
        },
        {
          id: 'ex_3',
          name: 'Leg Press 45º',
          category: 'Pernas',
          sets: 4,
          reps: 12,
          restSeconds: 90,
          weight: 160,
          image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=500&auto=format&fit=crop&q=60',
          equipment: 'Aparelho Leg Press'
        },
        {
          id: 'ex_4',
          name: 'Desenvolvimento com Halteres',
          category: 'Ombros',
          sets: 3,
          reps: 10,
          restSeconds: 60,
          weight: 18,
          image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=500&auto=format&fit=crop&q=60',
          equipment: 'Halteres'
        }
      ];
      localStorage.setItem('atlas_exercises', JSON.stringify(defaultExercises));
    }

    if (!localStorage.getItem('atlas_cardio_history')) {
      const defaultCardio = [
        { id: 'c_1', date: 'Ontem', type: 'Corrida ao Ar Livre', distanceKm: 4.8, durationMin: 26, paceMinKm: '5:25', calories: 340 },
        { id: 'c_2', date: '3 dias atrás', type: 'Caminhada Rápida', distanceKm: 3.2, durationMin: 32, paceMinKm: '10:00', calories: 185 }
      ];
      localStorage.setItem('atlas_cardio_history', JSON.stringify(defaultCardio));
    }
  }

  // Autenticação & Usuário
  getCurrentUser() {
    return JSON.parse(localStorage.getItem('atlas_current_user') || 'null');
  }

  saveCurrentUser(user) {
    localStorage.setItem('atlas_current_user', JSON.stringify(user));
  }

  // Exercícios
  getExercises() {
    return JSON.parse(localStorage.getItem('atlas_exercises') || '[]');
  }

  saveExercise(exercise) {
    const list = this.getExercises();
    if (!exercise.id) {
      exercise.id = 'ex_' + Date.now();
      list.push(exercise);
    } else {
      const idx = list.findIndex(e => e.id === exercise.id);
      if (idx !== -1) list[idx] = exercise;
      else list.push(exercise);
    }
    localStorage.setItem('atlas_exercises', JSON.stringify(list));
    return exercise;
  }

  deleteExercise(id) {
    const list = this.getExercises().filter(e => e.id !== id);
    localStorage.setItem('atlas_exercises', JSON.stringify(list));
    return list;
  }

  // Histórico de Cardio
  getCardioHistory() {
    return JSON.parse(localStorage.getItem('atlas_cardio_history') || '[]');
  }

  saveCardioSession(session) {
    const list = this.getCardioHistory();
    session.id = 'c_' + Date.now();
    session.date = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
    list.unshift(session);
    localStorage.setItem('atlas_cardio_history', JSON.stringify(list));
    return session;
  }

  // Treinos por Dia da Semana (Rotina Semanal)
  getWeeklySchedule() {
    let schedule = JSON.parse(localStorage.getItem('atlas_weekly_schedule') || 'null');
    if (!schedule) {
      const allEx = this.getExercises();
      schedule = {
        segunda: {
          dayKey: 'segunda',
          dayName: 'Segunda-feira',
          shortName: 'SEG',
          title: 'Treino A - Peito & Tríceps',
          isRest: false,
          focus: 'Superiores (Empurrar)',
          exercises: allEx.filter(e => e.category === 'Peito' || e.category === 'Braços').length > 0 
            ? allEx.filter(e => e.category === 'Peito' || e.category === 'Braços') 
            : [allEx[0]]
        },
        terca: {
          dayKey: 'terca',
          dayName: 'Terça-feira',
          shortName: 'TER',
          title: 'Treino B - Costas & Bíceps',
          isRest: false,
          focus: 'Superiores (Puxar)',
          exercises: allEx.filter(e => e.category === 'Costas').length > 0
            ? allEx.filter(e => e.category === 'Costas')
            : (allEx[1] ? [allEx[1]] : [])
        },
        quarta: {
          dayKey: 'quarta',
          dayName: 'Quarta-feira',
          shortName: 'QUA',
          title: 'Descanso Ativo ou Cardio',
          isRest: true,
          focus: 'Recuperação Muscular',
          exercises: []
        },
        quinta: {
          dayKey: 'quinta',
          dayName: 'Quinta-feira',
          shortName: 'QUI',
          title: 'Treino C - Pernas & Panturrilhas',
          isRest: false,
          focus: 'Membros Inferiores',
          exercises: allEx.filter(e => e.category === 'Pernas').length > 0
            ? allEx.filter(e => e.category === 'Pernas')
            : (allEx[2] ? [allEx[2]] : [])
        },
        sexta: {
          dayKey: 'sexta',
          dayName: 'Sexta-feira',
          shortName: 'SEX',
          title: 'Treino D - Ombros & Core',
          isRest: false,
          focus: 'Deltoides & Abdômen',
          exercises: allEx.filter(e => e.category === 'Ombros').length > 0
            ? allEx.filter(e => e.category === 'Ombros')
            : (allEx[3] ? [allEx[3]] : [])
        },
        sabado: {
          dayKey: 'sabado',
          dayName: 'Sábado',
          shortName: 'SÁB',
          title: 'Treino Funcional ou Cardio',
          isRest: false,
          focus: 'Resistência & Queima',
          exercises: []
        },
        domingo: {
          dayKey: 'domingo',
          dayName: 'Domingo',
          shortName: 'DOM',
          title: 'Descanso Total',
          isRest: true,
          focus: 'Regeneração Muscular',
          exercises: []
        }
      };
      localStorage.setItem('atlas_weekly_schedule', JSON.stringify(schedule));
    }
    return schedule;
  }

  saveDayWorkout(dayKey, data) {
    const schedule = this.getWeeklySchedule();
    if (schedule[dayKey]) {
      schedule[dayKey] = { ...schedule[dayKey], ...data };
      localStorage.setItem('atlas_weekly_schedule', JSON.stringify(schedule));
    }
    return schedule[dayKey];
  }

  addExerciseToDay(dayKey, exercise) {
    const schedule = this.getWeeklySchedule();
    if (schedule[dayKey]) {
      if (!schedule[dayKey].exercises) schedule[dayKey].exercises = [];
      schedule[dayKey].exercises.push(exercise);
      schedule[dayKey].isRest = false;
      localStorage.setItem('atlas_weekly_schedule', JSON.stringify(schedule));
    }
    return schedule[dayKey];
  }

  removeExerciseFromDay(dayKey, exerciseIndex) {
    const schedule = this.getWeeklySchedule();
    if (schedule[dayKey] && schedule[dayKey].exercises) {
      schedule[dayKey].exercises.splice(exerciseIndex, 1);
      localStorage.setItem('atlas_weekly_schedule', JSON.stringify(schedule));
    }
    return schedule[dayKey];
  }
}

export const AtlasDB = new AtlasStorageEngine();
