# ⚡ ATLAS - Treino, Saúde & Performance (GymTrack Style)

Aplicação web moderna e responsiva voltada para musculação, saúde integrativa com IA, nutrição personalizada, rastreamento contínuo de cardio em segundo plano e curadoria de suplementos.

![Atlas Logo](assets/logo.jpg)

---

## 📁 Estrutura de Arquivos

```text
Atlas/
├── assets/
│   └── logo.jpg               # Logo exclusiva Atlas Athletic Evolution
├── css/
│   └── style.css              # Design system GymTrack (Dark Obsidian & Verde Neon)
├── js/
│   ├── firebase-config.js     # Configuração Firebase Modular v10 + Motor Local Dual
│   ├── app.js                 # Controlador SPA, roteamento e eventos globais
│   ├── modules/
│   │   ├── auth.js            # Autenticação, perfis e isolamento por UID
│   │   ├── workout.js         # Treino GymTrack, Live HUD, contador e gerador IA
│   │   ├── health.js          # Dieta personalizada e guia de dores/pomadas
│   │   ├── shop.js            # Loja de suplementos, equipamentos e quiz
│   │   └── cardio.js          # Cardio com Web Worker e persistência
│   └── workers/
│       └── cardio-worker.js   # Web Worker para cronometragem contínua em segundo plano
├── index.html                 # Estrutura principal da Single Page Application
├── manifest.json              # Configuração PWA para instalação no celular
├── sw.js                      # Service Worker para cache e background
└── README.md                  # Documentação técnica e instruções
```

---

## 🚀 Como Executar o Projeto

1. Abra a pasta `Atlas` no terminal ou VS Code.
2. Inicie qualquer servidor estático local:
   - **Opção A (Python):** `python -m http.server 3000`
   - **Opção B (Node/npx):** `npx serve .`
   - **Opção C (VS Code):** Botão direito em `index.html` -> *Open with Live Server*.
3. Acesse no navegador: `http://localhost:3000` (ou porta indicada).

---

## 🔐 Configuração do Firebase (Authentication & Cloud Firestore)

O Atlas possui **suporte nativo dual**: ele funciona imediatamente em modo offline/demonstração e conecta-se ao Firebase Real assim que você inserir as credenciais.

1. Acesse o [Firebase Console](https://console.firebase.google.com/) e crie um projeto.
2. Ative o **Authentication** -> Provedor **E-mail/Senha**.
3. Crie um banco **Cloud Firestore** em modo de teste ou defina as seguintes regras:
   ```javascript
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{userId}/{document=**} {
         allow read, write: if request.auth != null && request.auth.uid == userId;
       }
     }
   }
   ```
4. Abra o arquivo `js/firebase-config.js` e insira sua `firebaseConfig`:
   ```javascript
   export const firebaseConfig = {
     apiKey: "SUA_API_KEY",
     authDomain: "seu-projeto.firebaseapp.com",
     projectId: "seu-projeto",
     storageBucket: "seu-projeto.appspot.com",
     messagingSenderId: "...",
     appId: "..."
   };
   ```

---

## 📱 Limitações Técnicas & Rastreamento em Segundo Plano

- **Suspensão de Abas em Mobile:** Navegadores móveis (Safari no iOS e Chrome no Android com modo de economia de energia) suspendem a execução de JavaScript quando a aba é minimizada sem áudio ativo.
- **Solução Implementada no Atlas:**
  1. **Web Worker Dedicado (`cardio-worker.js`):** Executa em thread separada.
  2. **Screen Wake Lock API:** Impede que o celular desligue a tela durante a corrida.
  3. **Cálculo Delta por Timestamp:** Mesmo se o sistema operacional congelar a aba temporariamente, ao reabrir o app o tempo real decorrido (`Date.now() - startTime`) é recalculado com 100% de precisão.
  4. **PWA:** Adicionar o site à tela de início do celular garante prioridade no ciclo de vida de segundo plano.

---

## ⚕️ Aviso Médico

O módulo de saúde possui caráter estritamente educativo e informativo. Orientações de pomadas e medicamentos de venda livre (MIP) não substituem avaliação médica presencial.
